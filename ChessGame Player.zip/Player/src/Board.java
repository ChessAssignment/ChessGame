///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//
////import Piece.Piece;
//import Board.Coordinate;
//import adt.ArrayList;
//import adt.ListInterface;
//
///**
// *
// * @author User
// */
//public class Board {
//        private Piece[][] board;
//        //public ListInterface board = new ArrayList<Piece>();
//        ListInterface b;
//        Coordinate coord;
//        Piece p;
//        
//    public Board() {
//        board = new Piece[8][8];
//        //board.add(new Coordinate(coord.getX(), coord.getY()));
//    }
//
//    public Board(Coordinate coord, Piece p) {
//        //board = new Piece[8][8];
//        this.coord = coord;
//        this.p = p;
//        
//    }
//    
//
//
//    
//    public boolean isPieceAt(int x, int y){
//    	return board[x][y] != null;
//    }
//    
//    public void placePieceAt(Piece p, Coordinate coord){
//    	if (isPieceAt(coord.getX(), coord.getX())){
//    		removePieceAt(coord);
//    	}   	
//    	if (p.getCoord() != null){
//    		removePieceAt(p.getCoord());
//    	}
//    	board[coord.getX()][coord.getY()] = p;
//    	p.setCoord(coord);
//    }
//    
//    private void removePieceAt(Coordinate coord){
//    	board[coord.getX()][coord.getY()] = null;        
//        //coord = null;
//    }
//    
//    public static boolean locationInBounds(Coordinate coord){
//    	return coord.getX() >= 0 && coord.getX() < 8 && coord.getY() >= 0 && coord.getY() < 8;
//    }
//    
//    public Piece getPieceAt(Coordinate coord) {
//        return board[coord.getX()][coord.getY()];
//    }
//
//    
//    public String toString()
//    {
//        //Coordinate coord = new Coordinate();
//        Board bi;
//    	String s = "  0 1 2 3 4 5 6 7\n";
//    	for(int x = 0; x < 8; x++){
//    		s += x;
//    		for(int y = 0; y < 8; y++){
////                        bi = (Board)b.getEntry(y);
////                        coord = bi.getCoord();
////                        int COL = coord.getX();
//
//
//                    if(board[x][y] != null){
//                  
//                        s += " " + board[x][y].getId();
//                    }
//                    else
//                    {
//                        s += " -";
//                    }
//    		}
//    		s += "\n";
//    	}
//    	return s;
//    }
//    
////    public String toString(){
////        for (int i = 0; i < b.getLength(); i++){
////            p = (Piece)b.getEntry(i);
////            int COL = coord.getX();
////            Piece s = (Piece)White_Pieces.getEntry(i);
////            
////        }
////        return p.getId();
////    }
//    
////    public String toString(){
////        return " This is id: " + p.getId() + " " + p.getId();
////    }
//    
//    
//
//    public Coordinate getCoord() {
//        return coord;
//    }    
//
//    public void setCoord(Coordinate coord) {
//        this.coord = coord;
//    }
//
//    public Piece getP() {
//        return p;
//    }
//
//    public void setP(Piece p) {
//        this.p = p;
//    }
//    
//    
//}
