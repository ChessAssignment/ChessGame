/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sim Wei Sheng
 */

import adt.ArrayList;
import adt.ListInterface;
import adt.SortedArrayList;
import adt.SortedListInterface;
import java.util.Scanner;

public class GameRound {
    
    public GameRound(){
        Scanner s = new Scanner(System.in);
        String name1, name2, input1, input2;
        boolean gameOver = false;
        
        Player player1, player2;
        ListInterface<Player> playerList = new ArrayList<>();
        SortedListInterface<Double> leaderboard = new SortedArrayList<>();
        
        while (!gameOver){
        System.out.print("=========================\n");
        System.out.print("Welcome to Chess Game !!!\n");
        System.out.print("=========================\n");
        
        do{
        System.out.print("Player 1 name : ");
        name1 = s.nextLine();
        }while (checkLetter(name1) == false);
        
        //player.add(name1);
        player1 = new Player(name1);
        playerList.add(player1);
        //System.out.print(player.toString());
        
        do{
        System.out.print("Player 2 name : ");
        name2 = s.nextLine();
        }while (checkLetter(name2) == false);
        
        player2 = new Player(name2);
        playerList.add(player2);
        
        System.out.print(name1 + "\n");
        // Board b = new Board();
        System.out.print(name2 = "\n");
        
        do{
        System.out.print(name1 + "'s turn\n");
        System.out.print("Move  - M\n");
        System.out.print("Reset - R\n");
        System.out.print("Quit  - Q\n");
        System.out.print("Please one (M/R/Q) : ");
        input1 = s.nextLine();
        
        if (input1.equalsIgnoreCase("M"))
        {
            // move
            break;
        }
        else if (input1.equalsIgnoreCase("R"))
        {
            System.out.print("Reset game ....\n");
            // Board b = new Board();
            break;
        }
        else if (input1.equalsIgnoreCase("Q"))
        {
            System.out.print("Quit game ....\n");
            break;
        }
        }while (input1 != "R" || input1 != "M" || input1 != "Q" );
        
        System.out.print(name2 + "'s turn");
        System.out.print("Move  - M");
        System.out.print("Reset - R");
        System.out.print("Quit  - Q");
        
        // For winner
        System.out.print(playerList);
        }
        
        //System.out.print(name1+" lose !!\n"); 

    }
    
    public boolean checkLetter(String name)
    {
        if (name == null)
        {
            System.out.print("Invalid input !!!\n");
            return false;
        }
        for (int i = 0; i< name.length(); i++)
        {
            if(Character.isLetter(name.charAt(i)) == true)
                return true;
            else 
                System.out.print("Invalid input !!!\n");
                return false;
        }
        System.out.print("Invalid input !!!\n");
        return false;
    }
   
    
    public static void main(String[] args){
        GameRound gr = new GameRound();
        
    }

    
}
