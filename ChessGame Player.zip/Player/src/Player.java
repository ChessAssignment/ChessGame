
import adt.SortedArrayList;
import java.util.Objects;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Sim Wei Sheng
 */
public class Player{
    protected String name;
    protected int gamesPlayed;
    protected int gamesWon;
    protected double result;
    
    public Player(String name){
        this.name = name;
    }
    
    public Player(String name, int gamesPlayed, int gamesWon, double result){
	this.name = name;
	this.gamesPlayed = gamesPlayed;
	this.gamesWon = gamesWon;
        this.result = result;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public int getGamesWon() {
        return gamesWon;
    }

    public void setGamesWon(int gamesWon) {
        this.gamesWon = gamesWon;
    }
    
    public int updateGamesPlayed(){
        return gamesPlayed++;
    }
    
    public int updateGamesWon(){
        return gamesWon++;
    }
    
    public void winPercent(int gamesWon, int gamesPlayed){
        result = (double)((gamesWon*100)/gamesPlayed);
    }
    
    @Override
    public String toString() {
        return "Player{" + "name=" + name + ", gamesPlayed=" + gamesPlayed + ", gamesWon=" + gamesWon + '}';
    }
    
}
