

//import Piece.*;


public class Game {
    
    private Board board;
    //private King player1King;
    //private King player2King;

    public Game() {
    	board = new Board();
//    	setupTeam(0, "player1");
//    	setupTeam(7, "player2");
    }
    
//    private void setupTeam(int side, String player){
//    	int one = (side > 0) ? -1: 1;
//    	int colIncerment = 0;
//    	
//    	//Rook
//    	Piece r1 = new Rook(player, new Coordinate(side, colIncerment), this);
//    	Piece r2 = new Rook(player, new Coordinate(side, 7-colIncerment), this);
//    	colIncerment += 1;
//    	
//    	//Knight
//    	Piece n1 = new Knight(player, new Coordinate(side, colIncerment), this);
//    	Piece n2 = new Knight(player, new Coordinate(side, 7-colIncerment), this);
//    	colIncerment += 1;
//    	
//    	//Bishop
//    	Piece b1 = new Bishop(player, new Coordinate(side, colIncerment), this);
//    	Piece b2 = new Bishop(player, new Coordinate(side, 7-colIncerment), this);
//    	colIncerment += 1;
//    	
//    	// King and Queen
//    	if(player.equalsIgnoreCase("player1"))
//    	{
//    		player1King = new King(player, new Coordinate(side, colIncerment), this);
//    	}
//    	else
//    	{
//    		player2King = new King(player, new Coordinate(side, colIncerment), this);
//    	}
//    	
//    	Piece q = new Queen(player, new Coordinate(side, 7-colIncerment), this);
//    	
//    	//Pawns
//    	for(int i = 0; i < 8; i++)
//    	{
//    		Piece p = new Pawn(player, new Coordinate(side + one, i), this);
//    	}
//    }
    
    public Board getBoard()
    {
    	return board;
    }
    
   // public King getPlayer1King()
    {
    	//return player1King;
    }
    
    //public King getPlayer2King()
    {
    	//return player2King;
    }
}
