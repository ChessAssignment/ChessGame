package Chess.Movement;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author C
 */

import Player.Player;
import chess.Board.ChessLocation;

public class Movement {
    public String name; //change to public Player player;
    public String pieceType;
    public ChessLocation newCoords; //change to Coordinate newCoords;
    
    public Movement(){
    
    }
    
    public Movement(String name/*change to Player player*/, String pieceType, ChessLocation newCoords /*change to Coordinate newCoords*/){
        this.name = name;
        this.pieceType=pieceType;
        this.newCoords=newCoords;
    }
    
    public void setPlayer(String name){ /*change to public void setPlayer(Player player)*/
        this.name = name;
    }
    
    public void setPieceType(String pieceType){
        if (pieceType== "K")
        this.pieceType="King";
        
        else if (pieceType == "Q")
        this.pieceType="Queen";
        
        else if (pieceType == "B")
        this.pieceType="Bishop";
        
        else if (pieceType == "N")
        this.pieceType="Knight";
        
        else if (pieceType == "R")
        this.pieceType="Rook";
        
        else if (pieceType == "P")
        this.pieceType="Pawn";
        
    }

    public void setNewCoords(ChessLocation newCoords){ /*change to public void setNewCoords (Coordinate newCoords)*/
        this.newCoords=newCoords;
    }
    
    public String getName(){
        return this.name;
    }
    
    public String getPieceType(){
        return this.pieceType;
    }
    
    public ChessLocation getNewCoords(){
        return this.newCoords;   
    }
    
    @Override
    public String toString(){
        return name+" has moved "+pieceType+" to new location: "+newCoords;
    }


}
