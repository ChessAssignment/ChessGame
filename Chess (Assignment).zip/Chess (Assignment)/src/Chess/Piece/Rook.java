package chess.Piece;

import chess.Board.ChessLocation;
import chess.Board.ChessGame;

public class Rook extends ChessPiece{

    public Rook(String owner, ChessLocation initialLocation, ChessGame game) {
    	super(owner, initialLocation, game);
    	if(owner.equalsIgnoreCase("player1")){
    		id = "R";
    	}
    	else if(owner.equalsIgnoreCase("player2")){
    		id = "r";
    	}
    }
    
    public boolean moveTo(ChessLocation location){
    	if((chessLocation.getRow() == location.getRow()) != (chessLocation.getCol() == location.getCol())){
    		
    		return checkLineOfSight(chessLocation, location) && super.moveTo(location);
    	}
    	
    	return false;
    }
    
    protected void updateThreateningLocation(){
    	threateningLocations.clear();
    	
    	super.updateVertical(1);
    	super.updateVertical(-1);
    	super.updateHorizontal(1);
    	super.updateHorizontal(-1);
    }
}
