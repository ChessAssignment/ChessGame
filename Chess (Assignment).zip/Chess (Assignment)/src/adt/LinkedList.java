/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adt;

import Chess.Movement.Movement;

/**
 *
 * @author C
 */


public class LinkedList <T> implements movementListInterface <T> {
    
    private Node firstNode;
    private int numberOfEntries;
    private Node lastNode;
    
    public LinkedList() {
        clear();
    }
    
     private class Node {
        private T data;
        private Node next;
        private Node previous;

        public Node(T data) {
            this.data = data;
        }
        
        public Node(T data, Node next, Node previous) {
            this.data = data;
            this.next = next;
            this.previous = previous;
        }    
    }
    
    public boolean add(T newEntry){
         Node newNode = new Node(newEntry);                                      
        
        if(isEmpty()) {                                                         
            firstNode = newNode;
            lastNode = newNode;
        }
        else {
            lastNode.next = newNode;
            newNode.previous = lastNode;
            lastNode = newNode;            
        }
        numberOfEntries++;
        return true;
    }
    
    public boolean add(int newPosition, T newEntry){
         if((newPosition >= 1) && (newPosition <= numberOfEntries + 1)) {
            Node newNode = new Node(newEntry);
            
            if(isEmpty()) {                                                     
                firstNode = newNode;
                lastNode = newNode;
            }
            else if(newPosition == 1) {                                         
                firstNode.previous = newNode;
                newNode.next = firstNode;                
                firstNode = newNode;        
            }
            else {                                                              
                Node nodeBefore = firstNode;
                for(int i = 1 ; i < newPosition - 1 ; ++i) {
                nodeBefore = nodeBefore.next;                                     
                }
            newNode.previous = nodeBefore;                                      
            newNode.next = nodeBefore.next;
            nodeBefore.next = newNode;
            nodeBefore.next.previous = newNode;  
            }
            numberOfEntries++;  
        }
        else {
            return false;
        }
        return true; 
    }
    
    public T remove(int givenPosition){
        T result = null;                                                        
        
        if((givenPosition >=1) && (givenPosition <= numberOfEntries)) {
            if(givenPosition == 1) {                                            
                result = firstNode.data;                                        
                firstNode = firstNode.next;               
            }
            else {                                                              
                Node nodeBefore = firstNode;
                for(int i = 1 ; i < givenPosition - 1 ; ++i) {
                    nodeBefore = nodeBefore.next;   
                }
                result = nodeBefore.next.data;
                nodeBefore.next = nodeBefore.next.next;
                nodeBefore.next = nodeBefore.next;
                //nodeBefore.next.next.previous = nodeBefore.next;   
            }
            numberOfEntries--;   
        }
        return result;       
    }
    
    public void clear(){
        firstNode = null;
        lastNode = null;
        numberOfEntries = 0;
    }
    
    public boolean replace(int givenPosition, T newEntry){
        if((givenPosition >= 1) &&(givenPosition <= numberOfEntries)) {
            Node currentNode = firstNode;
            for(int i = 0 ; i < givenPosition - 1 ; ++i) {
                currentNode = currentNode.next;   
            }
            currentNode.data = newEntry;                                        
        }
        else {
            return false;
        }
        return true;     
    }
    
    public T getEntry(int givenPosition){
        T result  = null;
        
        if((givenPosition >= 1) && (givenPosition <= numberOfEntries)) {
            Node currentNode = firstNode;
            for(int i = 0 ; i < givenPosition - 1 ; ++i) {
                currentNode = currentNode.next;
            }
            result = currentNode.data;                                                    
        }
        return result;  
    }
    
    
    public boolean contains(T anEntry){
        boolean found = false;
        Node currentNode = firstNode;
        
        while((!found) && (currentNode != null)) {
            if(anEntry.equals(currentNode.data)) {
                found = true;
            }
            else {
                currentNode = currentNode.next;
            }
        }
       return found;
    }
    
    public boolean isEmpty(){
        boolean result;        
        result = numberOfEntries == 0;
        return result;
    }
    
    public boolean isFull(){
        return false;
    }
    
    @Override
    public String toString(){
        Node newNode = lastNode;
        T result = lastNode.data;

        Movement movement = (Movement) result;
        String output = "\n"+movement.toString()+"\n";
        return output;
    }
}
