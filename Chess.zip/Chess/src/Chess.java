/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;
import Chess.Board.*;
import Chess.Piece.*;

import Chess.Movement.Movement;
import adt.LinkedList;
import chess.Board.ChessBoard;
import chess.Board.ChessGame;
import chess.Board.ChessLocation;
import chess.Piece.ChessPiece;
import chess.Piece.King;

/**
 *
 * @author User
 */
public class Chess {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
    	ChessGame chessGame = new ChessGame();
    	boolean gameOver = false;
    	String currentPlayer = "player1";
    	Scanner scanner = new Scanner(System.in);
    	String input;
    	
    	ChessLocation newLocation;
    	ChessPiece currentPiece;
    	King king;
        
        //movement list
        LinkedList <Movement> move = new LinkedList<>();
        Movement movement = new Movement();
    	//end of movement list
        
    	while(!gameOver){
    		try{
    			System.out.println(chessGame.getChessBoard().toString());
    			System.out.println(currentPlayer + "'s Turn");
    			System.out.println("M - Move");
    			System.out.println("Q - Quit");
    			System.out.println("R - Reset");
    			input = scanner.nextLine();
    			if(input.equalsIgnoreCase("Q") || input.equalsIgnoreCase("QUIT")){
    				gameOver = true;
    				System.out.println("=====Game has been abandoned=====");
    				continue;
    			}
    			else if(input.equalsIgnoreCase("R") || input.equalsIgnoreCase("RESET")){
    				chessGame = new ChessGame();
    				System.out.println("=====Reset Game=====");
    				continue;
    		    }
    		    else if(input.equalsIgnoreCase("M") || input.equalsIgnoreCase("MOVE")){
    		    	
    		    	if(currentPlayer.equals("player1")){
    		    		king = chessGame.getPlayer1King();
    		    		
    		    	}
    		    	else
    		    	{
    		    		king = chessGame.getPlayer2King();
    		    	}
    		    	ChessPiece danger = king.check();
    		    	if(danger != null){
    		    		System.out.println("Your King is in check from piece at:(" + danger.getChessLocation().getRow() + ", " + danger.getChessLocation().getCol() + ").");
    		    		}
    		    		
    		    		currentPiece = getCurrentPiece(chessGame, currentPlayer);
    		    		newLocation = getNewLocation();
    		    		
    		    		if(currentPiece.moveTo(newLocation)){
    		    			currentPlayer = (currentPlayer.equalsIgnoreCase("player1")) ? "player2": "player1";
                                        
                                        //display movement history 
                                        if (currentPlayer.equalsIgnoreCase("player2")){ //change the validation (if equals to player1)
                                            movement.setPlayer("Player 1"); //change to movement.setPlayer(player.name);
                                            movement.setPieceType(currentPiece.id);
                                            movement.setNewCoords(newLocation);                 
                                        }
                                        else if (currentPlayer.equalsIgnoreCase("player1")){ //change the validation (if equals to player2)
                                            movement.setPlayer("Player 2"); //change to movement.setPlayer(player.name);
                                            movement.setPieceType(currentPiece.id);
                                            movement.setNewCoords(newLocation);
                                        }
 
                                        move.add(movement);
                                        System.out.println(move.toString());
                                        //end of movement history
                                        
    		    		}
    		    		else
    		    		{
    		    			System.out.println("Move was invalid, try again.");
    		    		}
    		    }
    	}
    	catch(ArrayIndexOutOfBoundsException | NumberFormatException e){
    		System.out.println("Couldn't parse input.");
    		e.printStackTrace();
    		
    	}
    	catch(NullPointerException e){
    		System.out.println("NullPointerException :(, GL Debugging");
    		e.printStackTrace();
    	}
    }
        
    
    
    }
    
    public static ChessPiece getCurrentPiece(ChessGame chessGame, String currentPlayer){
    	Scanner scanner = new Scanner(System.in);
    	String input;
    	ChessLocation currentLocation;
    	ChessPiece currentPiece;  
        
    	while(true){
    		System.out.println("Move from: row, col");
    		input = scanner.nextLine();
    		currentLocation = createChessLocation(input);
                
    		if(!ChessBoard.locationInBounds(currentLocation)){
    			System.out.println("Location not on board, try again.");
    			continue;
    		}
    		currentPiece = chessGame.getChessBoard().getPieceAt(currentLocation);
                
    		if(currentPiece == null){
    			System.out.println("Invalid piece selected, out of bounds.");
    		}
    		else if (currentPiece.getOwner().equalsIgnoreCase(currentPlayer)){
                    return currentPiece;
    		}
    		else{
    			System.out.println("Invalid piece selected, not your piece.");
    		}
    	}
    }
    
    public static ChessLocation getNewLocation(){
    	Scanner scanner = new Scanner(System.in);
    	String input;

    	ChessLocation newLocation;
    	
    	while (true){
    		System.out.println("Move to: row, col");
    		input = scanner.nextLine();
    		newLocation = createChessLocation(input);
                
    		if(!ChessBoard.locationInBounds(newLocation)){
    			System.out.println("Invalid location selected, out of bounds.");
    		}
    		else{
    			return newLocation;
    		}
    	}
    }
    
    private static ChessLocation createChessLocation(String input){
    	int row = Integer.parseInt(input.split(",")[0].trim());
    	int col = Integer.parseInt(input.split(",")[1].trim());
    	return new ChessLocation(row, col);
    }
    
}