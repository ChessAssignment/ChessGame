package chess.Piece;

import chess.Board.ChessGame;
import chess.Board.ChessLocation;

public interface ChessPieceInterface{
	public boolean moveTo(ChessLocation location);
}
