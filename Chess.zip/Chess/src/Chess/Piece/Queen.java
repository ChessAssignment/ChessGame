package chess.Piece;

import chess.Board.ChessLocation;
import chess.Board.ChessGame;

public class Queen extends ChessPiece{

    public Queen(String owner, ChessLocation initialLocation, ChessGame game){
    	super(owner, initialLocation, game);
    	if(owner.equalsIgnoreCase("player1")){
    		id = "Q";
    	}
    	else if(owner.equalsIgnoreCase("player2")){
    		id = "q";
    	}
    }
    
    public boolean moveTo(ChessLocation location){
    	return checkLineOfSight(chessLocation, location) && super.moveTo(location);
    }
    
    protected void updateThreateningLocation(){
    	threateningLocations.clear();
    	
    	super.updateVertical(1);
    	super.updateVertical(-1);
    	
    	super.updateHorizontal(1);
    	super.updateHorizontal(-1);
    	
    	super.updateDiagonal(1, 1);
    	super.updateDiagonal(-1, 1);
    	super.updateDiagonal(1, -1);
    	super.updateDiagonal(-1, -1);
    }
    
}
