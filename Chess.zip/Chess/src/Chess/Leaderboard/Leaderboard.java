/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Leaderboard;

/**
 *
 * @author Admin
 */

public class Leaderboard implements Comparable<Leaderboard>{
    
    private String name;
    private int gaemsWon;
    private int gamesPlayed;
    private int winPercent;

    public Leaderboard(String name, int gaemsWon, int gamesPlayed, int winPercent) {
        this.name = name;
        this.gaemsWon = gaemsWon;
        this.gamesPlayed = gamesPlayed;
        this.winPercent = winPercent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGaemsWon() {
        return gaemsWon;
    }

    public void setGaemsWon(int gaemsWon) {
        this.gaemsWon = gaemsWon;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public int getWinPercent() {
        return winPercent;
    }

    public void setWinPercent(int winPercent) {
        this.winPercent = winPercent;
    }
    
    
   
    @Override
    public int compareTo(Leaderboard l) {
        
        int compareWinPercent = l.getWinPercent();
        
        return compareWinPercent - this.getWinPercent();
        
    }
}
