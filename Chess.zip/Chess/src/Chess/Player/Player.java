package Player;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Sim Wei Sheng
 */
public class Player{
    private String name;
    private int gamesPlayed;
    private int gamesWon;
    private int winPercent;
    
    public Player(String name, int gamesPlayed, int gamesWon, int winPercent){
	this.name = name;
	this.gamesPlayed = gamesPlayed;
	this.gamesWon = gamesWon;
        this.winPercent = winPercent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public int getGamesWon() {
        return gamesWon;
    }

    public void setGamesWon(int gamesWon) {
        this.gamesWon = gamesWon;
    }

    public int getWinPercent() {
        return winPercent;
    }

    public void setWinPercent(int winPercent) {
        this.winPercent = winPercent;
    }
    
    public int updateGamesPlayed(){
        return gamesPlayed++;
    }
    
    public int updateGamesWon(){
        return gamesWon++;
    }
    
    public void winPercent(int gamesWon, int gamesPlayed){
        winPercent = ((gamesWon*100)/gamesPlayed);
    }
    
    
    @Override
    public String toString() {
        return name + "\t" + gamesWon + "\t" + gamesPlayed + "\t" + winPercent + "\n";
    }


}
