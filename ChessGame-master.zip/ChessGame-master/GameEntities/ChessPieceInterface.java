package GameEntities;

import Chess.ChessGame;
import Chess.ChessLocation;

public interface ChessPieceInterface {
    public boolean moveTo(ChessLocation location);
}
